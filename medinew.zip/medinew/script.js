/* ============================================================
   MediLinks – script.js
   Handles: mobile nav, form validation, scroll-reveal,
            stat counter animation
   ============================================================ */

'use strict';

/* ── DOM ready ─────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  initHamburger();
  initFormValidation();
  initScrollReveal();
  initStatCounters();
});

/* ============================================================
   1. MOBILE HAMBURGER MENU
   ============================================================ */
function initHamburger() {
  const hamburger = document.getElementById('hamburger');
  const navLinks  = document.getElementById('navLinks');

  if (!hamburger || !navLinks) return;

  hamburger.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('open');
    hamburger.classList.toggle('open', isOpen);
    hamburger.setAttribute('aria-expanded', isOpen);
  });

  /* Close menu when any link is clicked (mobile UX) */
  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      navLinks.classList.remove('open');
      hamburger.classList.remove('open');
      hamburger.setAttribute('aria-expanded', 'false');
    });
  });

  /* Close on outside click */
  document.addEventListener('click', (e) => {
    if (!hamburger.contains(e.target) && !navLinks.contains(e.target)) {
      navLinks.classList.remove('open');
      hamburger.classList.remove('open');
      hamburger.setAttribute('aria-expanded', 'false');
    }
  });
}

/* ============================================================
   2. CONTACT FORM VALIDATION
   ============================================================ */
function initFormValidation() {
  const form = document.getElementById('contactForm');
  if (!form) return;

  /* ── Helpers ──────────────────────────────────────────── */
  function showError(groupId, errorId, message) {
    const group = document.getElementById(groupId);
    const error = document.getElementById(errorId);
    if (!group || !error) return;
    group.classList.add('error');
    error.textContent = message;
    error.style.display = 'block';
  }

  function clearError(groupId, errorId) {
    const group = document.getElementById(groupId);
    const error = document.getElementById(errorId);
    if (!group || !error) return;
    group.classList.remove('error');
    error.style.display = 'none';
  }

  function isValidEmail(email) {
    /* RFC-5321-ish: local@domain.tld */
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    return re.test(email.trim());
  }

  /* ── Live clear on input ──────────────────────────────── */
  document.getElementById('name')?.addEventListener('input', () => clearError('grpName',    'nameError'));
  document.getElementById('email')?.addEventListener('input', () => clearError('grpEmail',   'emailError'));
  document.getElementById('message')?.addEventListener('input', () => clearError('grpMessage','messageError'));

  /* ── Submit ───────────────────────────────────────────── */
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const nameVal    = document.getElementById('name')?.value.trim()    ?? '';
    const emailVal   = document.getElementById('email')?.value.trim()   ?? '';
    const messageVal = document.getElementById('message')?.value.trim() ?? '';

    let valid = true;

    /* Validate Name */
    if (!nameVal) {
      showError('grpName', 'nameError', 'Please enter your full name.');
      valid = false;
    } else {
      clearError('grpName', 'nameError');
    }

    /* Validate Email */
    if (!emailVal) {
      showError('grpEmail', 'emailError', 'Please enter your email address.');
      valid = false;
    } else if (!isValidEmail(emailVal)) {
      showError('grpEmail', 'emailError', 'Please enter a valid email address (e.g. you@example.com).');
      valid = false;
    } else {
      clearError('grpEmail', 'emailError');
    }

    /* Validate Message */
    if (!messageVal) {
      showError('grpMessage', 'messageError', 'Please enter your message before submitting.');
      valid = false;
    } else if (messageVal.length < 10) {
      showError('grpMessage', 'messageError', 'Your message is too short. Please add a bit more detail.');
      valid = false;
    } else {
      clearError('grpMessage', 'messageError');
    }

    /* If all valid – show success */
    if (valid) {
      handleSuccessfulSubmit(form);
    }
  });
}

/**
 * Handles the post-validation success state:
 * shows the success banner, disables the form, scrolls to it.
 */
function handleSuccessfulSubmit(form) {
  const successBanner = document.getElementById('formSuccess');
  const submitBtn     = document.getElementById('submitBtn');

  /* Update button state */
  if (submitBtn) {
    submitBtn.textContent = '✅ Message Sent!';
    submitBtn.disabled = true;
    submitBtn.style.opacity = '0.7';
    submitBtn.style.cursor = 'default';
  }

  /* Show success banner */
  if (successBanner) {
    successBanner.classList.add('show');
    successBanner.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  /* Reset form fields (keep the banner visible) */
  setTimeout(() => {
    form.reset();
    /* Re-enable after 5 seconds for demo purposes */
    if (submitBtn) {
      submitBtn.textContent = 'Send Message ✉️';
      submitBtn.disabled = false;
      submitBtn.style.opacity = '';
      submitBtn.style.cursor = '';
    }
    if (successBanner) {
      successBanner.classList.remove('show');
    }
  }, 5000);
}

/* ============================================================
   3. SCROLL-REVEAL FOR CARDS
   Uses IntersectionObserver so cards animate when visible.
   ============================================================ */
function initScrollReveal() {
  /* Cards start invisible via JS; CSS animation plays on entry */
  const cards = document.querySelectorAll('.card, .mv-card, .team-card, .stat__num');

  if (!('IntersectionObserver' in window)) return;

  /* Start invisible (CSS animation is already set via animation-fill-mode:both) */
  cards.forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(28px)';
    card.style.transition = 'opacity 0.55s ease, transform 0.55s ease';
  });

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        /* Small stagger delay based on position among siblings */
        const siblings = Array.from(entry.target.parentElement?.children ?? []);
        const index    = siblings.indexOf(entry.target);
        const delay    = Math.min(index * 80, 320); /* max 320ms stagger */

        setTimeout(() => {
          entry.target.style.opacity  = '1';
          entry.target.style.transform = 'translateY(0)';
        }, delay);

        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  cards.forEach(card => observer.observe(card));
}

/* ============================================================
   4. ANIMATED STAT COUNTERS
   Increments numbers in .stat__num on first scroll into view.
   ============================================================ */
function initStatCounters() {
  const statNums = document.querySelectorAll('.stat__num');
  if (!statNums.length || !('IntersectionObserver' in window)) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      observer.unobserve(entry.target);

      const el       = entry.target;
      const raw      = el.textContent;          /* e.g. "1,200+" or "4.9 ⭐" */
      const numMatch = raw.match(/[\d,.]+/);     /* grab the number */
      if (!numMatch) return;

      const suffix   = raw.replace(numMatch[0], ''); /* everything else */
      const target   = parseFloat(numMatch[0].replace(/,/g, ''));
      const isFloat  = numMatch[0].includes('.');
      const duration = 1400; /* ms */
      const start    = performance.now();

      function tick(now) {
        const elapsed  = now - start;
        const progress = Math.min(elapsed / duration, 1);
        /* Ease-out */
        const eased    = 1 - Math.pow(1 - progress, 3);
        const current  = target * eased;

        if (isFloat) {
          el.textContent = current.toFixed(1) + suffix;
        } else if (target >= 1000) {
          el.textContent = Math.floor(current).toLocaleString('en-IN') + suffix;
        } else {
          el.textContent = Math.floor(current) + suffix;
        }

        if (progress < 1) requestAnimationFrame(tick);
      }

      requestAnimationFrame(tick);
    });
  }, { threshold: 0.5 });

  statNums.forEach(el => observer.observe(el));
}
